#ifndef MODE_CLEAROFFSET_H
#define MODE_CLEAROFFSET_H

void mode_clearOffset(void);

#endif
