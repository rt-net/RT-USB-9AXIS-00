#ifndef MODESELECT_H
#define MODESELECT_H

void modeSelect(void);

#endif
