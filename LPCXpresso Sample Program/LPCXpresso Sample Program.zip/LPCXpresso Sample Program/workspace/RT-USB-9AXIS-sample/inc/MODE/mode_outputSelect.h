#ifndef MODE_OUTPUTSELECT_H
#define MODE_OUTPUTSELECT_H

void mode_outputSelect(void);

#endif


