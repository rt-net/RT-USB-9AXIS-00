/* ------------------------------------------------------------ *
File MainFunction.h

* ------------------------------------------------------------ */
#ifndef MAINFUNCTION_H
#define MAINFUNCTION_H

void startTimerInterruptMainFunction(void);
void stopTimerInterruptMainFunction(void);
void setSendDataEnable(uint8_t en);

#endif

/******************************************************************************
**                            End Of File
******************************************************************************/
