#ifndef MDOE_CALIBOMEGA_H
#define MDOE_CALIBOMEGA_H

void mode_calibOmega(void);

#endif
