#ifndef MDOE_VIEWALLDATA_H
#define MDOE_VIEWALLDATA_H

void mode_viewAllData(void);

#endif
