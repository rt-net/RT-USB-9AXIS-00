#ifndef MDOE_CALIBMAG_H
#define MDOE_CALIBMAG_H

void mode_calibMag(void);

#endif
